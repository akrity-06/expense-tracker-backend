import Expense from '../models/Expense.js';
import User from '../models/User.js';
import { asyncHandler } from '../middleware/errorHandler.js';

// Helper function to get user ID from Clerk ID
const getUserId = async (clerkUserId) => {
  const user = await User.findByClerkId(clerkUserId);
  if (!user) {
    throw new Error('User not found. Please sync your account first.');
  }
  return user.id;
};

// @desc    Create new expense
// @route   POST /api/expenses
// @access  Private
export const createExpense = asyncHandler(async (req, res) => {
  const userId = await getUserId(req.auth.userId);
  const expenseData = req.body;

  const expense = await Expense.create(userId, expenseData);

  res.status(201).json({
    success: true,
    message: 'Expense created successfully',
    data: expense
  });
});

// @desc    Get all expenses
// @route   GET /api/expenses
// @access  Private
export const getExpenses = asyncHandler(async (req, res) => {
  const userId = await getUserId(req.auth.userId);
  
  // Extract query parameters for filtering
  const { startDate, endDate, category } = req.query;
  const filters = {};
  
  if (startDate) filters.startDate = startDate;
  if (endDate) filters.endDate = endDate;
  if (category) filters.category = category;

  const expenses = await Expense.findByUserId(userId, filters);

  res.json({
    success: true,
    count: expenses.length,
    data: expenses
  });
});

// @desc    Get single expense
// @route   GET /api/expenses/:id
// @access  Private
export const getExpense = asyncHandler(async (req, res) => {
  const userId = await getUserId(req.auth.userId);
  const expenseId = parseInt(req.params.id);

  const expense = await Expense.findById(expenseId);

  if (!expense) {
    return res.status(404).json({
      success: false,
      error: 'Expense not found'
    });
  }

  // Verify expense belongs to user
  if (expense.user_id !== userId) {
    return res.status(403).json({
      success: false,
      error: 'Not authorized to access this expense'
    });
  }

  res.json({
    success: true,
    data: expense
  });
});

// @desc    Update expense
// @route   PUT /api/expenses/:id
// @access  Private
export const updateExpense = asyncHandler(async (req, res) => {
  const userId = await getUserId(req.auth.userId);
  const expenseId = parseInt(req.params.id);
  const expenseData = req.body;

  const expense = await Expense.update(expenseId, userId, expenseData);

  if (!expense) {
    return res.status(404).json({
      success: false,
      error: 'Expense not found or not authorized'
    });
  }

  res.json({
    success: true,
    message: 'Expense updated successfully',
    data: expense
  });
});

// @desc    Delete expense
// @route   DELETE /api/expenses/:id
// @access  Private
export const deleteExpense = asyncHandler(async (req, res) => {
  const userId = await getUserId(req.auth.userId);
  const expenseId = parseInt(req.params.id);

  const deleted = await Expense.delete(expenseId, userId);

  if (!deleted) {
    return res.status(404).json({
      success: false,
      error: 'Expense not found or not authorized'
    });
  }

  res.json({
    success: true,
    message: 'Expense deleted successfully'
  });
});

// @desc    Get expense statistics
// @route   GET /api/expenses/stats
// @access  Private
export const getExpenseStats = asyncHandler(async (req, res) => {
  const userId = await getUserId(req.auth.userId);
  const { period } = req.query; // daily, monthly, yearly

  const stats = await Expense.getStatistics(userId, period);

  res.json({
    success: true,
    data: stats
  });
});
