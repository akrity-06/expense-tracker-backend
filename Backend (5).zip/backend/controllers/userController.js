import User from '../models/User.js';
import { getClerkUser } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errorHandler.js';

// @desc    Get current user profile
// @route   GET /api/users/me
// @access  Private
export const getProfile = asyncHandler(async (req, res) => {
  const clerkUserId = req.auth.userId;

  // Get user from database
  let user = await User.findByClerkId(clerkUserId);

  // If user doesn't exist in database, fetch from Clerk and create
  if (!user) {
    const clerkUser = await getClerkUser(clerkUserId);
    if (!clerkUser) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    const email = clerkUser.emailAddresses[0]?.emailAddress || '';
    user = await User.create(clerkUserId, email);
  }

  res.json({
    success: true,
    data: {
      id: user.id,
      clerkUserId: user.clerk_user_id,
      email: user.email,
      createdAt: user.created_at
    }
  });
});

// @desc    Sync user from Clerk
// @route   POST /api/users/sync
// @access  Private
export const syncUser = asyncHandler(async (req, res) => {
  const clerkUserId = req.auth.userId;

  // Get user from Clerk
  const clerkUser = await getClerkUser(clerkUserId);
  if (!clerkUser) {
    return res.status(404).json({
      success: false,
      error: 'User not found in Clerk'
    });
  }

  const email = clerkUser.emailAddresses[0]?.emailAddress || '';

  // Find or create user in database
  const user = await User.findOrCreate(clerkUserId, email);

  res.json({
    success: true,
    message: 'User synced successfully',
    data: {
      id: user.id,
      clerkUserId: user.clerk_user_id,
      email: user.email,
      createdAt: user.created_at
    }
  });
});
