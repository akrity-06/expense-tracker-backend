import { body, param, validationResult } from 'express-validator';

// Validation error handler
export const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array().map(err => ({
        field: err.path,
        message: err.msg
      }))
    });
  }
  next();
};

// Expense validation rules
export const expenseValidation = {
  create: [
    body('date')
      .notEmpty()
      .withMessage('Date is required')
      .isDate()
      .withMessage('Invalid date format'),
    body('amount')
      .notEmpty()
      .withMessage('Amount is required')
      .isFloat({ min: 0.01 })
      .withMessage('Amount must be greater than 0'),
    body('category')
      .notEmpty()
      .withMessage('Category is required')
      .trim()
      .isLength({ min: 1, max: 100 })
      .withMessage('Category must be between 1 and 100 characters'),
    body('description')
      .optional()
      .trim()
      .isLength({ max: 500 })
      .withMessage('Description must not exceed 500 characters')
  ],
  update: [
    param('id')
      .isInt({ min: 1 })
      .withMessage('Invalid expense ID'),
    body('date')
      .optional()
      .isDate()
      .withMessage('Invalid date format'),
    body('amount')
      .optional()
      .isFloat({ min: 0.01 })
      .withMessage('Amount must be greater than 0'),
    body('category')
      .optional()
      .trim()
      .isLength({ min: 1, max: 100 })
      .withMessage('Category must be between 1 and 100 characters'),
    body('description')
      .optional()
      .trim()
      .isLength({ max: 500 })
      .withMessage('Description must not exceed 500 characters')
  ],
  delete: [
    param('id')
      .isInt({ min: 1 })
      .withMessage('Invalid expense ID')
  ]
};
