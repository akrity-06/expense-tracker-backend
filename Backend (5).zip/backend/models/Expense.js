import pool from '../config/database.js';

class Expense {
  // Create new expense
  static async create(userId, expenseData) {
    try {
      const { date, amount, category, description } = expenseData;
      const [result] = await pool.query(
        'INSERT INTO expenses (user_id, date, amount, category, description) VALUES (?, ?, ?, ?, ?)',
        [userId, date, amount, category, description || null]
      );
      
      return await Expense.findById(result.insertId);
    } catch (error) {
      console.error('Error creating expense:', error);
      throw error;
    }
  }

  // Get all expenses for a user
  static async findByUserId(userId, filters = {}) {
    try {
      let query = 'SELECT * FROM expenses WHERE user_id = ?';
      const params = [userId];

      // Add date filters if provided
      if (filters.startDate) {
        query += ' AND date >= ?';
        params.push(filters.startDate);
      }
      if (filters.endDate) {
        query += ' AND date <= ?';
        params.push(filters.endDate);
      }
      if (filters.category) {
        query += ' AND category = ?';
        params.push(filters.category);
      }

      query += ' ORDER BY date DESC, created_at DESC';

      const [rows] = await pool.query(query, params);
      return rows;
    } catch (error) {
      console.error('Error finding expenses:', error);
      throw error;
    }
  }

  // Find expense by ID
  static async findById(id) {
    try {
      const [rows] = await pool.query(
        'SELECT * FROM expenses WHERE id = ?',
        [id]
      );
      return rows[0] || null;
    } catch (error) {
      console.error('Error finding expense by ID:', error);
      throw error;
    }
  }

  // Update expense
  static async update(id, userId, expenseData) {
    try {
      // First verify the expense belongs to the user
      const expense = await Expense.findById(id);
      if (!expense || expense.user_id !== userId) {
        return null;
      }

      const updates = [];
      const values = [];

      if (expenseData.date !== undefined) {
        updates.push('date = ?');
        values.push(expenseData.date);
      }
      if (expenseData.amount !== undefined) {
        updates.push('amount = ?');
        values.push(expenseData.amount);
      }
      if (expenseData.category !== undefined) {
        updates.push('category = ?');
        values.push(expenseData.category);
      }
      if (expenseData.description !== undefined) {
        updates.push('description = ?');
        values.push(expenseData.description);
      }

      if (updates.length === 0) {
        return expense;
      }

      values.push(id);
      const query = `UPDATE expenses SET ${updates.join(', ')} WHERE id = ?`;
      
      await pool.query(query, values);
      return await Expense.findById(id);
    } catch (error) {
      console.error('Error updating expense:', error);
      throw error;
    }
  }

  // Delete expense
  static async delete(id, userId) {
    try {
      // First verify the expense belongs to the user
      const expense = await Expense.findById(id);
      if (!expense || expense.user_id !== userId) {
        return false;
      }

      await pool.query('DELETE FROM expenses WHERE id = ?', [id]);
      return true;
    } catch (error) {
      console.error('Error deleting expense:', error);
      throw error;
    }
  }

  // Get expense statistics
  static async getStatistics(userId, period = 'monthly') {
    try {
      let dateGroup;
      switch (period) {
        case 'daily':
          dateGroup = 'DATE(date)';
          break;
        case 'monthly':
          dateGroup = 'DATE_FORMAT(date, "%Y-%m")';
          break;
        case 'yearly':
          dateGroup = 'YEAR(date)';
          break;
        default:
          dateGroup = 'DATE_FORMAT(date, "%Y-%m")';
      }

      // Total by period
      const [totalByPeriod] = await pool.query(
        `SELECT ${dateGroup} as period, SUM(amount) as total
         FROM expenses
         WHERE user_id = ?
         GROUP BY period
         ORDER BY period DESC
         LIMIT 12`,
        [userId]
      );

      // Total by category
      const [totalByCategory] = await pool.query(
        `SELECT category, SUM(amount) as total, COUNT(*) as count
         FROM expenses
         WHERE user_id = ?
         GROUP BY category
         ORDER BY total DESC`,
        [userId]
      );

      // Overall totals
      const [overallStats] = await pool.query(
        `SELECT 
          SUM(amount) as total,
          COUNT(*) as count,
          AVG(amount) as average,
          MIN(amount) as minimum,
          MAX(amount) as maximum
         FROM expenses
         WHERE user_id = ?`,
        [userId]
      );

      return {
        totalByPeriod,
        totalByCategory,
        overall: overallStats[0] || {
          total: 0,
          count: 0,
          average: 0,
          minimum: 0,
          maximum: 0
        }
      };
    } catch (error) {
      console.error('Error getting statistics:', error);
      throw error;
    }
  }
}

export default Expense;
