import pool from '../config/database.js';

class User {
  // Find user by Clerk ID
  static async findByClerkId(clerkUserId) {
    try {
      const [rows] = await pool.query(
        'SELECT * FROM users WHERE clerk_user_id = ?',
        [clerkUserId]
      );
      return rows[0] || null;
    } catch (error) {
      console.error('Error finding user:', error);
      throw error;
    }
  }

  // Create new user
  static async create(clerkUserId, email) {
    try {
      const [result] = await pool.query(
        'INSERT INTO users (clerk_user_id, email) VALUES (?, ?)',
        [clerkUserId, email]
      );
      return {
        id: result.insertId,
        clerk_user_id: clerkUserId,
        email
      };
    } catch (error) {
      // Handle duplicate key error
      if (error.code === 'ER_DUP_ENTRY') {
        return await User.findByClerkId(clerkUserId);
      }
      console.error('Error creating user:', error);
      throw error;
    }
  }

  // Find or create user
  static async findOrCreate(clerkUserId, email) {
    try {
      let user = await User.findByClerkId(clerkUserId);
      if (!user) {
        user = await User.create(clerkUserId, email);
      }
      return user;
    } catch (error) {
      console.error('Error in findOrCreate:', error);
      throw error;
    }
  }

  // Get user by ID
  static async findById(id) {
    try {
      const [rows] = await pool.query(
        'SELECT * FROM users WHERE id = ?',
        [id]
      );
      return rows[0] || null;
    } catch (error) {
      console.error('Error finding user by ID:', error);
      throw error;
    }
  }
}

export default User;
