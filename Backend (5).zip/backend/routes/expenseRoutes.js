import express from 'express';
import {
  createExpense,
  getExpenses,
  getExpense,
  updateExpense,
  deleteExpense,
  getExpenseStats
} from '../controllers/expenseController.js';
import { requireAuth } from '../middleware/auth.js';
import { expenseValidation, validate } from '../middleware/validation.js';

const router = express.Router();

// All routes require authentication
router.use(requireAuth);

// @route   GET /api/expenses/stats
router.get('/stats', getExpenseStats);

// @route   POST /api/expenses
router.post('/', expenseValidation.create, validate, createExpense);

// @route   GET /api/expenses
router.get('/', getExpenses);

// @route   GET /api/expenses/:id
router.get('/:id', getExpense);

// @route   PUT /api/expenses/:id
router.put('/:id', expenseValidation.update, validate, updateExpense);

// @route   DELETE /api/expenses/:id
router.delete('/:id', expenseValidation.delete, validate, deleteExpense);

export default router;
