import express from 'express';
import { getProfile, syncUser } from '../controllers/userController.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

// All routes require authentication
router.use(requireAuth);

// @route   GET /api/users/me
router.get('/me', getProfile);

// @route   POST /api/users/sync
router.post('/sync', syncUser);

export default router;
